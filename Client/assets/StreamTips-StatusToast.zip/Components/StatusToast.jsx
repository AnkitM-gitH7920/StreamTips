import React, { useEffect } from "react";
import { Check, X } from "lucide-react";
import "../css/status-toast.css";

export default function StatusToast({
  type = "success",
  message = "",
  duration = 3500,
  onClose
}) {
  useEffect(() => {
    if (!message || !duration) return;
    const timer = setTimeout(() => onClose?.(), duration);
    return () => clearTimeout(timer);
  }, [message, duration, onClose]);

  if (!message) return null;

  const success = type === "success";

  return (
    <div className={`status-toast ${success ? "status-toast-success" : "status-toast-error"}`}>
      <div className="status-toast-icon">
        {success
          ? <Check size={18} strokeWidth={3} />
          : <X size={18} strokeWidth={3} />}
      </div>

      <p className="status-toast-message">{message}</p>

      <button
        className="status-toast-close"
        onClick={onClose}
        aria-label="Close notification"
      >
        <X size={15} />
      </button>
    </div>
  );
}
